export function isHttpsUrl(value) {
  try {
    return new URL(value).protocol === "https:";
  } catch {
    return false;
  }
}

// Checks the image URL and the documents list.
// Returns { error, documents }: documents comes back trimmed, without empty rows.
export function validateAttachments(linkImg, documents) {
  if (linkImg && !isHttpsUrl(linkImg)) {
    return { error: "La URL de la imagen debe empezar con https://", documents: [] };
  }

  const cleaned = documents
    .map((d) => ({ name: d.name.trim(), url: d.url.trim() }))
    .filter((d) => d.name || d.url);

  for (const d of cleaned) {
    if (!d.name) {
      return { error: "Cada documento necesita un nombre", documents: [] };
    }
    if (!isHttpsUrl(d.url)) {
      return { error: `La URL de "${d.name}" debe empezar con https://`, documents: [] };
    }
  }

  return { error: "", documents: cleaned };
}
