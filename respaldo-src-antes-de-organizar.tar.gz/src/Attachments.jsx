import { FileText, Plus, Trash2 } from "lucide-react";

function Attachments({ linkImg, setLinkImg, documents, setDocuments }) {
  function updateDocument(index, field, value) {
    setDocuments(
      documents.map((d, i) => (i === index ? { ...d, [field]: value } : d))
    );
  }

  function removeDocument(index) {
    setDocuments(documents.filter((_, i) => i !== index));
  }

  function addDocument() {
    setDocuments([...documents, { name: "", url: "" }]);
  }

  return (
    <div>
      <label className="field-label">Imagen (URL)</label>
      <input
        className="field-input"
        placeholder="https://..."
        value={linkImg}
        onChange={(e) => setLinkImg(e.target.value)}
      />

      <label className="field-label">Archivos adjuntos</label>
      {documents.map((d, index) => (
        <div className="document-row" key={index}>
          <FileText size={20} />
          <input
            placeholder="Nombre (ej. Guía de renovación.pdf)"
            value={d.name}
            onChange={(e) => updateDocument(index, "name", e.target.value)}
          />
          <input
            placeholder="https://..."
            value={d.url}
            onChange={(e) => updateDocument(index, "url", e.target.value)}
          />
          <button
            type="button"
            className="icon-action danger"
            aria-label="Quitar documento"
            onClick={() => removeDocument(index)}
          >
            <Trash2 size={16} />
          </button>
        </div>
      ))}

      <button type="button" className="btn-add" onClick={addDocument}>
        <Plus size={16} /> Añadir documento
      </button>
    </div>
  );
}

export default Attachments;
